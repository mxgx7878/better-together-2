const AboutPage = () => {
  const coreValues = [
    {
      title: 'Support',
      description: 'Providing comprehensive support to participants and their families throughout their NDIS journey.',
      icon: '🤝',
      color: 'bg-ndis-green',
    },
    {
      title: 'Innovation',
      description: 'Leveraging technology to create better connections and improve service delivery.',
      icon: '💡',
      color: 'bg-ndis-red',
    },
    {
      title: 'Empowerment',
      description: 'Empowering participants with choice and control over their disability support.',
      icon: '⚡',
      color: 'bg-ndis-yellow',
    },
    {
      title: 'Quality',
      description: 'Maintaining the highest standards in provider connections and service excellence.',
      icon: '⭐',
      color: 'bg-ndis-purple',
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-ndis-purple to-ndis-green text-white py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">About NDIS Connect</h1>
          <p className="text-xl">
            Building bridges between participants and providers through innovation and technology
          </p>
        </div>
      </section>

      {/* Mission & Vision Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12">
            {/* Mission */}
            <div className="bg-gray-50 p-8 rounded-lg border-l-4 border-ndis-green">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Mission</h2>
              <p className="text-lg text-gray-600 leading-relaxed">
                To create an accessible, user-friendly platform that connects NDIS participants 
                with quality service providers, fostering meaningful relationships and enabling 
                participants to exercise choice and control in their support journey.
              </p>
            </div>

            {/* Vision */}
            <div className="bg-gray-50 p-8 rounded-lg border-l-4 border-ndis-purple">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Vision</h2>
              <p className="text-lg text-gray-600 leading-relaxed">
                A future where every NDIS participant can easily find and connect with the right 
                support services, and where providers can reach those who need their expertise, 
                creating a thriving ecosystem of care and support.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6 text-center">
            Who We Are
          </h2>
          <p className="text-lg text-gray-600 leading-relaxed mb-6">
            NDIS Connect is a digital platform dedicated to simplifying the process of finding 
            and connecting with NDIS service providers. We understand the challenges participants 
            face in navigating the NDIS landscape, and we're here to make that journey easier.
          </p>
          <p className="text-lg text-gray-600 leading-relaxed mb-6">
            Our platform brings together participants seeking support and providers offering 
            quality services, creating a transparent marketplace where informed decisions can 
            be made. We believe in the power of technology to transform lives and make 
            disability support more accessible for everyone.
          </p>
          <p className="text-lg text-gray-600 leading-relaxed">
            By providing tools for discovery, comparison, and connection, we're helping to build 
            stronger relationships between participants and providers, ultimately contributing to 
            better outcomes for the entire NDIS community.
          </p>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Core Values
            </h2>
            <p className="text-lg text-gray-600">
              The principles that guide everything we do
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {coreValues.map((value, index) => (
              <div
                key={index}
                className="bg-white border-2 border-gray-200 rounded-lg p-6 hover:shadow-xl transition-all duration-200 hover:-translate-y-2"
              >
                <div className={`${value.color} w-16 h-16 rounded-full flex items-center justify-center text-3xl mb-4`}>
                  {value.icon}
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{value.title}</h3>
                <p className="text-gray-600 leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Team
            </h2>
            <p className="text-lg text-gray-600">
              Meet the people making NDIS Connect possible
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[1, 2, 3].map((member) => (
              <div key={member} className="bg-white rounded-lg p-6 text-center shadow-md hover:shadow-xl transition-shadow duration-200">
                <div className="w-32 h-32 bg-gradient-to-br from-ndis-purple to-ndis-green rounded-full mx-auto mb-4 flex items-center justify-center text-white text-4xl font-bold">
                  TM
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Team Member {member}</h3>
                <p className="text-ndis-purple font-semibold mb-3">Role Title</p>
                <p className="text-gray-600">
                  Passionate about improving accessibility and support for NDIS participants.
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-ndis-purple text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Why Choose NDIS Connect?
          </h2>
          <div className="grid md:grid-cols-3 gap-8 mt-12">
            <div>
              <div className="text-4xl font-bold text-ndis-yellow mb-2">1000+</div>
              <p className="text-lg">Registered Providers</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-ndis-yellow mb-2">5000+</div>
              <p className="text-lg">Active Participants</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-ndis-yellow mb-2">24/7</div>
              <p className="text-lg">Platform Access</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;
