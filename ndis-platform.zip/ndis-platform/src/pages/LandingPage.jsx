const LandingPage = () => {
  const upcomingEvents = [
    { id: 1, title: 'NDIS Information Session', date: 'Jan 20, 2026', link: '#' },
    { id: 2, title: 'Provider Workshop', date: 'Jan 25, 2026', link: '#' },
    { id: 3, title: 'Community Meetup', date: 'Feb 01, 2026', link: '#' },
  ];

  const featuredProviders = [
    'Provider 1', 'Provider 2', 'Provider 3', 'Provider 4',
    'Provider 5', 'Provider 6', 'Provider 7', 'Provider 8',
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-ndis-purple to-ndis-green text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Welcome to NDIS Connect
          </h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
            Connecting participants with quality service providers. 
            Empowering lives through innovation and support.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-ndis-yellow text-gray-900 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-yellow-400 transition-all duration-200 shadow-lg">
              Get Started
            </button>
            <button className="bg-white text-ndis-purple px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-all duration-200 shadow-lg">
              Learn More
            </button>
          </div>
        </div>
      </section>

      {/* Event Calendar Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Upcoming Events
            </h2>
            <p className="text-lg text-gray-600">
              Join us for workshops, information sessions, and community events
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 mb-8">
            {upcomingEvents.map((event) => (
              <div key={event.id} className="bg-gray-50 border-2 border-ndis-green rounded-lg p-6 hover:shadow-lg transition-shadow duration-200">
                <div className="text-ndis-purple font-bold text-sm mb-2">{event.date}</div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">{event.title}</h3>
                <a 
                  href={event.link} 
                  className="inline-block bg-ndis-yellow text-gray-900 px-6 py-2 rounded-lg font-semibold hover:bg-yellow-400 transition-colors duration-200"
                >
                  Register on Eventbrite
                </a>
              </div>
            ))}
          </div>

          <div className="text-center">
            <a 
              href="#" 
              className="inline-flex items-center text-ndis-purple font-semibold hover:text-purple-700 transition-colors duration-200"
            >
              <svg className="w-6 h-6 mr-2" fill="currentColor" viewBox="0 0 24 24">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
              </svg>
              Join our Facebook Community
            </a>
          </div>
        </div>
      </section>

      {/* Join Us Section */}
      <section className="py-16 bg-ndis-green text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Join Our Community Today
          </h2>
          <p className="text-xl mb-8">
            Whether you're a participant looking for support or a provider wanting to connect, 
            NDIS Connect is here for you. Sign up to access our platform and discover new possibilities.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-ndis-yellow text-gray-900 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-yellow-400 transition-all duration-200 shadow-lg">
              Join as Participant
            </button>
            <button className="bg-ndis-red text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-red-500 transition-all duration-200 shadow-lg">
              Join as Provider
            </button>
          </div>
        </div>
      </section>

      {/* Featured Providers Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Featured Providers
            </h2>
            <p className="text-lg text-gray-600">
              Trusted service providers in our network
            </p>
          </div>

          {/* Scrolling Logo Section */}
          <div className="relative overflow-hidden py-8">
            <div className="flex animate-scroll space-x-8">
              {[...featuredProviders, ...featuredProviders].map((provider, index) => (
                <div 
                  key={index} 
                  className={`flex-shrink-0 w-40 h-32 rounded-lg flex items-center justify-center text-white font-semibold text-center shadow-lg ${
                    index === 0 ? 'bg-ndis-purple' : 'bg-ndis-green'
                  }`}
                >
                  {provider}
                </div>
              ))}
            </div>
          </div>

          <div className="text-center mt-8">
            <a 
              href="/subscription" 
              className="inline-block bg-ndis-purple text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-purple-700 transition-colors duration-200 shadow-lg"
            >
              Become a Featured Provider
            </a>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-ndis-red text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Get Started?
          </h2>
          <p className="text-xl mb-8">
            Create your free account today and start exploring the possibilities
          </p>
          <button className="bg-white text-ndis-red px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-all duration-200 shadow-lg">
            Create Free Account
          </button>
        </div>
      </section>

      <style jsx>{`
        @keyframes scroll {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-50%);
          }
        }
        .animate-scroll {
          animation: scroll 20s linear infinite;
        }
      `}</style>
    </div>
  );
};

export default LandingPage;
