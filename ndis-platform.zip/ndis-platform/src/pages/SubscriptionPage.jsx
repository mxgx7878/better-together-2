const SubscriptionPage = () => {
  const plans = [
    {
      name: 'Basic Plan',
      price: 'Free',
      description: 'Perfect for getting started with NDIS Connect',
      features: [
        'Browse provider profiles',
        'Basic search functionality',
        'Access to event calendar',
        'Community forum access',
        'Email support',
      ],
      buttonText: 'Get Started Free',
      buttonColor: 'bg-ndis-green hover:bg-green-600',
      highlight: false,
    },
    {
      name: 'Premium Plan',
      price: '$29',
      period: '/month',
      description: 'Unlock all features and get priority support',
      features: [
        'Everything in Basic',
        'Advanced search filters',
        'Direct messaging with providers',
        'Featured profile listing',
        'Priority support (24/7)',
        'Detailed analytics',
        'Custom recommendations',
        'Early event access',
      ],
      buttonText: 'Upgrade to Premium',
      buttonColor: 'bg-ndis-purple hover:bg-purple-700',
      highlight: true,
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-ndis-red to-ndis-yellow text-white py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Choose Your Plan</h1>
          <p className="text-xl">
            Select the plan that best fits your needs and start connecting today
          </p>
        </div>
      </section>

      {/* Subscription Plans */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {plans.map((plan, index) => (
              <div
                key={index}
                className={`bg-white rounded-2xl shadow-lg overflow-hidden transition-all duration-200 hover:shadow-2xl ${
                  plan.highlight ? 'ring-4 ring-ndis-purple transform md:scale-105' : ''
                }`}
              >
                {plan.highlight && (
                  <div className="bg-ndis-purple text-white text-center py-2 font-semibold">
                    MOST POPULAR
                  </div>
                )}
                
                <div className="p-8">
                  <h3 className="text-3xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                  <div className="mb-4">
                    <span className="text-5xl font-bold text-gray-900">{plan.price}</span>
                    {plan.period && <span className="text-xl text-gray-600">{plan.period}</span>}
                  </div>
                  <p className="text-gray-600 mb-6">{plan.description}</p>

                  <button className={`w-full ${plan.buttonColor} text-white py-4 px-6 rounded-lg font-semibold text-lg transition-all duration-200 shadow-lg mb-8`}>
                    {plan.buttonText}
                  </button>

                  <div className="space-y-4">
                    <h4 className="font-semibold text-gray-900 text-lg mb-4">What's included:</h4>
                    {plan.features.map((feature, idx) => (
                      <div key={idx} className="flex items-start">
                        <svg className="w-6 h-6 text-ndis-green mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                        <span className="text-gray-600">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Provider Subscription */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gradient-to-r from-ndis-purple to-ndis-green text-white rounded-2xl p-8 md:p-12 text-center shadow-2xl">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Are You a Service Provider?
            </h2>
            <p className="text-xl mb-8">
              Join our network of quality providers and connect with participants who need your services
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-ndis-yellow text-gray-900 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-yellow-400 transition-all duration-200 shadow-lg">
                View Provider Plans
              </button>
              <button className="bg-white text-ndis-purple px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-all duration-200 shadow-lg">
                Learn More
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-12 text-center">
            Frequently Asked Questions
          </h2>
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                Can I switch plans anytime?
              </h3>
              <p className="text-gray-600">
                Yes! You can upgrade or downgrade your plan at any time. Changes take effect immediately.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                Is there a free trial for Premium?
              </h3>
              <p className="text-gray-600">
                We offer a 14-day free trial for our Premium plan. No credit card required to start.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                What payment methods do you accept?
              </h3>
              <p className="text-gray-600">
                We accept all major credit cards, PayPal, and direct debit. All payments are secure and encrypted.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-ndis-red text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Get Started?
          </h2>
          <p className="text-xl mb-8">
            Join thousands of participants and providers using NDIS Connect
          </p>
          <button className="bg-white text-ndis-red px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-all duration-200 shadow-lg">
            Sign Up Now
          </button>
        </div>
      </section>
    </div>
  );
};

export default SubscriptionPage;
